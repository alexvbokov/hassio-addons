#!/usr/bin/with-contenv bashio

while true; 
do 
	python3 /valokaari.py || true; 
done
